import { expect, test } from "@playwright/test";

import { addWeightProductToCart, checkoutPickup, e2e, login, prisma } from "../fixtures";

test.describe("Operacao, pesagem, pagamento e estoque", () => {
  test("executa pedido por peso de 500 g com peso real de 518 g ate conclusao", async ({ page }) => {
    await addWeightProductToCart(page, 500);
    const orderId = await checkoutPickup(page, "Cliente E2E Peso", "92922220000");

    await login(page, e2e.users.attendantA1);
    await expect(page.getByRole("heading", { name: "Painel operacional" })).toBeVisible();
    await page.goto("/operacao");

    await expect(page.getByText(`Pedido #${orderId.slice(-6)}`)).toBeVisible();
    await page.getByRole("button", { name: "Aceitar" }).click();
    await expect(page.getByRole("button", { name: "Iniciar separação" })).toBeVisible();
    await page.getByRole("button", { name: "Iniciar separação" }).click();
    await expect(page.getByLabel("Peso real")).toBeVisible();
    await page.getByLabel("Peso real").fill("518");
    await page.getByRole("button", { name: "Confirmar" }).click();

    await expect(page.getByText("Peso real: 518 g")).toBeVisible();
    await expect(page.getByText("Valor final: R$ 21,76")).toBeVisible();
    await expect(page.getByText("Estimativa: R$ 21,00")).toBeVisible();

    await page.getByRole("button", { name: "Marcar pronto" }).click();
    await expect(page.getByRole("button", { name: "Finalizar" })).toBeVisible();
    await page.getByRole("button", { name: "Finalizar" }).click();
    await expect(page.getByText(`Pedido #${orderId.slice(-6)}`)).not.toBeVisible();

    const order = await prisma.order.findUniqueOrThrow({
      where: { id: orderId },
      include: { items: true, payments: true }
    });
    expect(order.status).toBe("COMPLETED");
    expect(order.totalCents).toBe(2176);
    expect(order.items[0]).toMatchObject({
      requestedQuantity: 500,
      actualQuantity: 518,
      priceCentsSnapshot: 4200,
      estimatedAmountCents: 2100,
      finalAmountCents: 2176
    });
    expect(order.payments).toHaveLength(1);
    expect(order.payments[0]).toMatchObject({ method: "CASH", amountCents: 2176 });

    const saleMovements = await prisma.stockMovement.findMany({
      where: { sourceId: orderId, type: "SALE" }
    });
    expect(saleMovements).toHaveLength(1);
    expect(saleMovements[0].quantityDelta).toBe(-518);
  });

  test("refresh apos pedido concluido nao duplica pagamento nem baixa de estoque", async ({ page }) => {
    await addWeightProductToCart(page, 500);
    const orderId = await checkoutPickup(page, "Cliente E2E Duplicidade", "92922220001");

    await login(page, e2e.users.attendantA1);
    await page.goto("/operacao");
    await page.getByText(`Pedido #${orderId.slice(-6)}`).waitFor();
    await page.getByRole("button", { name: "Aceitar" }).click();
    await page.getByRole("button", { name: "Iniciar separação" }).click();
    await page.getByLabel("Peso real").fill("500");
    await page.getByRole("button", { name: "Confirmar" }).click();
    await page.getByRole("button", { name: "Marcar pronto" }).click();
    await page.getByRole("button", { name: "Finalizar" }).click();
    await page.reload();

    expect(await prisma.payment.count({ where: { orderId } })).toBe(1);
    expect(await prisma.stockMovement.count({ where: { sourceId: orderId, type: "SALE" } })).toBe(1);
  });
});
