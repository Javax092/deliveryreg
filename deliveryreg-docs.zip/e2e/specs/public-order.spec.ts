import { expect, test } from "@playwright/test";

import {
  addUnitProductToCart,
  addWeightProductToCart,
  checkoutPickup,
  e2e,
  prisma
} from "../fixtures";

test.describe("Catalogo publico e pedido", () => {
  test("carrega catalogo por QR, monta carrinho e cria pedido de retirada", async ({ page }) => {
    await page.goto(`/catalogo?source=${e2e.sourceA1}`);

    await expect(page.getByText("E2E Filial A1")).toBeVisible();
    await expect(page.getByRole("link", { name: new RegExp(e2e.weightProductName) })).toBeVisible();
    await expect(page.getByRole("link", { name: new RegExp(e2e.unitProductName) })).toBeVisible();
    await expect(page.getByText("R$ 42,00/kg")).toBeVisible();

    await addUnitProductToCart(page);
    await page.getByRole("link", { name: "Ver carrinho" }).click();

    await expect(page.getByText(e2e.unitProductName)).toBeVisible();
    await expect(page.getByText("Total estimado")).toBeVisible();
    await expect(page.getByText("R$ 12,00", { exact: true })).toBeVisible();

    const orderId = await checkoutPickup(page, "Cliente E2E Retirada", "92911110000");
    await expect(page.getByText("Status: Novo")).toBeVisible();
    await expect(page.getByText(e2e.unitProductName)).toBeVisible();

    const order = await prisma.order.findUniqueOrThrow({
      where: { id: orderId },
      include: { items: true }
    });
    expect(order.status).toBe("CREATED");
    expect(order.fulfillmentType).toBe("PICKUP");
    expect(order.totalCents).toBe(1200);
    expect(order.items).toHaveLength(1);
  });

  for (const width of [360, 390, 430]) {
    test(`fluxo publico mobile em ${width}px nao tem overflow horizontal`, async ({ page }) => {
      await page.setViewportSize({ width, height: 780 });
      await addWeightProductToCart(page, 500);
      await page.getByRole("link", { name: "Ver carrinho" }).click();
      await expect(page.getByText("Total estimado")).toBeVisible();
      await expect(page.getByRole("button", { name: /Fazer pedido/ })).toBeVisible();

      const hasHorizontalOverflow = await page.evaluate(
        () => document.documentElement.scrollWidth > document.documentElement.clientWidth
      );
      expect(hasHorizontalOverflow).toBe(false);
    });
  }
});
