import { describe, expect, it, beforeEach, afterAll } from "vitest";
import { PrismaClient, type InternalRole } from "@prisma/client";

import { createPickupOrder } from "@/modules/orders/create-pickup-order";
import { completeOrder } from "@/modules/orders/complete-order";
import { confirmActualWeight, transitionOperationalOrder } from "@/modules/orders/operation";
import { createPosSale } from "@/modules/pos/create-pos-sale";
import { transferInventory } from "@/modules/inventory/operations";
import { assignDelivery } from "@/modules/delivery/operation";
import { hashPassword } from "@/modules/identity/password";
import type { AuthContext } from "@/modules/shared/auth/context";

const run = process.env.RUN_POSTGRES_TESTS === "1" ? describe : describe.skip;
const prisma = new PrismaClient();

async function resetDatabase() {
  await prisma.analyticsEvent.deleteMany();
  await prisma.auditLog.deleteMany();
  await prisma.stockMovement.deleteMany();
  await prisma.payment.deleteMany();
  await prisma.delivery.deleteMany();
  await prisma.orderStatusHistory.deleteMany();
  await prisma.orderItem.deleteMany();
  await prisma.order.deleteMany();
  await prisma.address.deleteMany();
  await prisma.lead.deleteMany();
  await prisma.customer.deleteMany();
  await prisma.idempotencyKey.deleteMany();
  await prisma.productBranchAvailability.deleteMany();
  await prisma.productPrice.deleteMany();
  await prisma.product.deleteMany();
  await prisma.productCategory.deleteMany();
  await prisma.deliveryZone.deleteMany();
  await prisma.leadSource.deleteMany();
  await prisma.userBranchAccess.deleteMany();
  await prisma.session.deleteMany();
  await prisma.user.deleteMany();
  await prisma.branch.deleteMany();
  await prisma.business.deleteMany();
}

async function createFixture() {
  const business = await prisma.business.create({
    data: {
      name: "Empresa Teste",
      timezone: "America/Manaus"
    }
  });
  const [branchA, branchB] = await Promise.all([
    prisma.branch.create({ data: { businessId: business.id, name: "Filial 1" } }),
    prisma.branch.create({ data: { businessId: business.id, name: "Filial 2" } })
  ]);
  const category = await prisma.productCategory.create({
    data: { businessId: business.id, name: "Queijos", slug: "queijos" }
  });
  const product = await prisma.product.create({
    data: {
      businessId: business.id,
      categoryId: category.id,
      name: "Queijo regional",
      slug: "queijo-regional",
      measurementType: "WEIGHT",
      baseUnit: "GRAM",
      sellingIncrement: 1,
      minimumOrderQuantity: 1
    }
  });
  await prisma.productPrice.create({
    data: {
      businessId: business.id,
      productId: product.id,
      priceCents: 4200,
      basisQuantity: 1000,
      basisUnit: "GRAM"
    }
  });
  await Promise.all(
    [branchA, branchB].map((branch) =>
      prisma.productBranchAvailability.create({
        data: { businessId: business.id, branchId: branch.id, productId: product.id }
      })
    )
  );
  const owner = await createUser(business.id, branchA.id, "owner@teste.local", "OWNER");
  const attendant = await createUser(business.id, branchA.id, "atendente@teste.local", "ATTENDANT");
  const courier = await createUser(business.id, branchA.id, "entrega@teste.local", "DELIVERY");
  const source = await prisma.leadSource.create({
    data: { businessId: business.id, branchId: branchA.id, code: "qr-filial-1", label: "QR Filial 1" }
  });
  await prisma.deliveryZone.create({
    data: {
      businessId: business.id,
      branchId: branchA.id,
      name: "Centro",
      normalizedName: "centro",
      feeCents: 800,
      minimumOrderCents: 100
    }
  });
  await prisma.stockMovement.create({
    data: {
      businessId: business.id,
      branchId: branchA.id,
      productId: product.id,
      type: "PURCHASE",
      quantityDelta: 1000,
      reason: "Carga inicial"
    }
  });

  return { business, branchA, branchB, product, owner, attendant, courier, source };
}

async function createUser(
  businessId: string,
  branchId: string,
  email: string,
  role: InternalRole
) {
  const user = await prisma.user.create({
    data: {
      businessId,
      email,
      name: email.split("@")[0],
      role,
      passwordHash: await hashPassword("senha-de-teste")
    }
  });
  await prisma.userBranchAccess.create({ data: { userId: user.id, branchId } });
  return user;
}

function context(user: { id: string; businessId: string; role: InternalRole }, branchIds: string[]): AuthContext {
  return { userId: user.id, businessId: user.businessId, role: user.role, branchIds };
}

async function createReadyOrder(fixture: Awaited<ReturnType<typeof createFixture>>) {
  const created = await createPickupOrder({
    businessId: fixture.business.id,
    branchId: fixture.branchA.id,
    leadSourceId: fixture.source.id,
    anonymousId: "anon-1",
    idempotencyKey: `pedido-${crypto.randomUUID()}`,
    customer: { name: "Cliente Teste", whatsapp: "92999999999" },
    items: [{ productId: fixture.product.id, requestedQuantity: 500 }]
  });
  const createdOrderId = typeof created === "object" && created && "orderId" in created ? String(created.orderId) : "";
  const order = await prisma.order.findUniqueOrThrow({ where: { id: createdOrderId }, include: { items: true } });
  const ctx = context(fixture.attendant, [fixture.branchA.id]);
  await transitionOperationalOrder({ context: ctx, orderId: order.id, toStatus: "ACCEPTED" });
  await transitionOperationalOrder({ context: ctx, orderId: order.id, toStatus: "PREPARING" });
  await transitionOperationalOrder({ context: ctx, orderId: order.id, toStatus: "READY" });
  return prisma.order.findUniqueOrThrow({ where: { id: order.id }, include: { items: true } });
}

beforeEach(resetDatabase);
afterAll(async () => prisma.$disconnect());

run("PostgreSQL comercial e concorrência", () => {
  it("finaliza venda ponderada com pagamento, baixa de estoque e snapshot de preço", async () => {
    const fixture = await createFixture();
    const order = await createReadyOrder(fixture);
    const ctx = context(fixture.attendant, [fixture.branchA.id]);

    const weight = await confirmActualWeight({
      context: ctx,
      orderItemId: order.items[0].id,
      actualQuantity: 518,
      idempotencyKey: "peso-1"
    });
    expect(weight).toMatchObject({
      requestedQuantity: 500,
      actualQuantity: 518,
      estimatedAmountCents: 2100,
      finalAmountCents: 2176
    });

    await completeOrder({ context: ctx, orderId: order.id, idempotencyKey: "fim-1", paymentMethod: "PIX" });

    const persisted = await prisma.order.findUniqueOrThrow({
      where: { id: order.id },
      include: { items: true, payments: true }
    });
    expect(persisted.status).toBe("COMPLETED");
    expect(persisted.totalCents).toBe(2176);
    expect(persisted.items[0]).toMatchObject({
      requestedQuantity: 500,
      actualQuantity: 518,
      estimatedAmountCents: 2100,
      finalAmountCents: 2176,
      priceCentsSnapshot: 4200
    });
    expect(persisted.payments).toHaveLength(1);
    expect(persisted.payments[0].amountCents).toBe(2176);
    const saleMovements = await prisma.stockMovement.findMany({ where: { sourceId: order.id, type: "SALE" } });
    expect(saleMovements).toHaveLength(1);
    expect(saleMovements[0].quantityDelta).toBe(-518);
  });

  it("preserva histórico quando o preço atual muda", async () => {
    const fixture = await createFixture();
    const order = await createReadyOrder(fixture);
    await prisma.productPrice.updateMany({
      where: { businessId: fixture.business.id, productId: fixture.product.id, endsAt: null },
      data: { endsAt: new Date() }
    });
    await prisma.productPrice.create({
      data: {
        businessId: fixture.business.id,
        productId: fixture.product.id,
        priceCents: 5000,
        basisQuantity: 1000,
        basisUnit: "GRAM"
      }
    });

    const item = await prisma.orderItem.findFirstOrThrow({ where: { orderId: order.id } });
    expect(item.priceCentsSnapshot).toBe(4200);
    expect(item.estimatedAmountCents).toBe(2100);
  });

  it("transfere estoque atomically sem criar quantidade", async () => {
    const fixture = await createFixture();
    const ctx = context(fixture.owner, [fixture.branchA.id, fixture.branchB.id]);
    await transferInventory({
      context: ctx,
      fromBranchId: fixture.branchA.id,
      toBranchId: fixture.branchB.id,
      productId: fixture.product.id,
      quantity: 300,
      reason: "Reposição"
    });

    const byBranch = await Promise.all(
      [fixture.branchA.id, fixture.branchB.id].map((branchId) =>
        prisma.stockMovement.aggregate({
          where: { businessId: fixture.business.id, branchId, productId: fixture.product.id },
          _sum: { quantityDelta: true }
        })
      )
    );
    expect(byBranch[0]._sum.quantityDelta).toBe(700);
    expect(byBranch[1]._sum.quantityDelta).toBe(300);
    expect((byBranch[0]._sum.quantityDelta ?? 0) + (byBranch[1]._sum.quantityDelta ?? 0)).toBe(1000);
  });

  it("não duplica efeitos em dupla conclusão do mesmo pedido", async () => {
    const fixture = await createFixture();
    const order = await createReadyOrder(fixture);
    const ctx = context(fixture.attendant, [fixture.branchA.id]);

    const results = await Promise.allSettled([
      completeOrder({ context: ctx, orderId: order.id, idempotencyKey: "fim-a" }),
      completeOrder({ context: ctx, orderId: order.id, idempotencyKey: "fim-b" })
    ]);

    expect(results.filter((result) => result.status === "fulfilled")).toHaveLength(1);
    const saleMovements = await prisma.stockMovement.findMany({ where: { sourceId: order.id, type: "SALE" } });
    expect(saleMovements).toHaveLength(1);
  });

  it("não duplica venda no retry idempotente do PDV", async () => {
    const fixture = await createFixture();
    const ctx = context(fixture.attendant, [fixture.branchA.id]);
    const [first, second] = await Promise.all([
      createPosSale({
        context: ctx,
        branchId: fixture.branchA.id,
        productId: fixture.product.id,
        quantity: 100,
        paymentMethod: "PIX",
        idempotencyKey: "pdv-retry"
      }),
      createPosSale({
        context: ctx,
        branchId: fixture.branchA.id,
        productId: fixture.product.id,
        quantity: 100,
        paymentMethod: "PIX",
        idempotencyKey: "pdv-retry"
      })
    ]);
    expect(first).toEqual(second);
    expect(await prisma.order.count({ where: { salesChannel: "POS" } })).toBe(1);
    expect(await prisma.stockMovement.count({ where: { type: "SALE" } })).toBe(1);
  });

  it("impede consumo concorrente acima do estoque disponível", async () => {
    const fixture = await createFixture();
    await prisma.stockMovement.deleteMany({ where: { productId: fixture.product.id } });
    await prisma.stockMovement.create({
      data: {
        businessId: fixture.business.id,
        branchId: fixture.branchA.id,
        productId: fixture.product.id,
        type: "PURCHASE",
        quantityDelta: 600,
        reason: "Estoque limitado"
      }
    });
    const ctx = context(fixture.attendant, [fixture.branchA.id]);
    const sale = (key: string) =>
      createPosSale({
        context: ctx,
        branchId: fixture.branchA.id,
        productId: fixture.product.id,
        quantity: 400,
        paymentMethod: "PIX",
        idempotencyKey: key
      });

    const results = await Promise.allSettled([sale("sale-a"), sale("sale-b")]);
    expect(results.filter((result) => result.status === "fulfilled")).toHaveLength(1);
    const total = await prisma.stockMovement.aggregate({
      where: { productId: fixture.product.id },
      _sum: { quantityDelta: true }
    });
    expect(total._sum.quantityDelta).toBeGreaterThanOrEqual(0);
  });

  it("resolve corrida de confirmação de peso com apenas uma confirmação", async () => {
    const fixture = await createFixture();
    const order = await createReadyOrder(fixture);
    const ctx = context(fixture.attendant, [fixture.branchA.id]);

    const results = await Promise.allSettled([
      confirmActualWeight({ context: ctx, orderItemId: order.items[0].id, actualQuantity: 518, idempotencyKey: "peso-a" }),
      confirmActualWeight({ context: ctx, orderItemId: order.items[0].id, actualQuantity: 520, idempotencyKey: "peso-b" })
    ]);

    expect(results.filter((result) => result.status === "fulfilled")).toHaveLength(1);
    const item = await prisma.orderItem.findUniqueOrThrow({ where: { id: order.items[0].id } });
    expect([518, 520]).toContain(item.actualQuantity);
  });

  it("isola empresas em leitura e mutação direta de operações", async () => {
    const fixtureA = await createFixture();
    const fixtureB = await createFixture();
    const ctxA = context(fixtureA.attendant, [fixtureA.branchA.id]);
    const orderB = await createReadyOrder(fixtureB);

    await expect(
      completeOrder({ context: ctxA, orderId: orderB.id, idempotencyKey: "cross" })
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
  });

  it("atribui entrega apenas para entregador autorizado da filial e audita", async () => {
    const fixture = await createFixture();
    const created = await createPickupOrder({
      businessId: fixture.business.id,
      branchId: fixture.branchA.id,
      leadSourceId: fixture.source.id,
      anonymousId: "anon-delivery",
      idempotencyKey: "delivery-1",
      fulfillmentType: "DELIVERY",
      address: { street: "Rua A", number: "10", neighborhood: "Centro" },
      customer: { name: "Cliente Entrega", whatsapp: "92988888888" },
      items: [{ productId: fixture.product.id, requestedQuantity: 500 }]
    });
    const createdOrderId = typeof created === "object" && created && "orderId" in created ? String(created.orderId) : "";
    const delivery = await prisma.delivery.findFirstOrThrow({ where: { orderId: createdOrderId } });
    const ctx = context(fixture.owner, [fixture.branchA.id]);

    await assignDelivery({ context: ctx, deliveryId: delivery.id, deliveryUserId: fixture.courier.id });

    const assigned = await prisma.delivery.findUniqueOrThrow({ where: { id: delivery.id } });
    expect(assigned.assignedUserId).toBe(fixture.courier.id);
    expect(await prisma.auditLog.count({ where: { action: "DELIVERY_ASSIGNED" } })).toBe(1);
  });
});
