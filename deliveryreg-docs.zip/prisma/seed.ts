import { PrismaClient } from "@prisma/client";

import { hashPassword } from "../src/modules/identity/password";

const prisma = new PrismaClient();

const initialBranches = ["Centro", "Ponta Negra"];

async function main() {
  const business = await prisma.business.upsert({
    where: { id: "business_deliveryreg_manaus" },
    update: {},
    create: {
      id: "business_deliveryreg_manaus",
      name: "DeliveryReg Manaus",
      timezone: "America/Manaus"
    }
  });

  const branches = await Promise.all(
    initialBranches.map((name) =>
      prisma.branch.upsert({
        where: {
          businessId_name: {
            businessId: business.id,
            name
          }
        },
        update: {
          isActive: true
        },
        create: {
          businessId: business.id,
          name
        }
      })
    )
  );

  const owner = await prisma.user.upsert({
    where: {
      businessId_email: {
        businessId: business.id,
        email: "admin@deliveryreg.local"
      }
    },
    update: {
      isActive: true,
      role: "OWNER"
    },
    create: {
      businessId: business.id,
      email: "admin@deliveryreg.local",
      name: "Administrador",
      role: "OWNER",
      passwordHash: await hashPassword("troque-esta-senha")
    }
  });

  await Promise.all(
    branches.map((branch) =>
      prisma.userBranchAccess.upsert({
        where: {
          userId_branchId: {
            userId: owner.id,
            branchId: branch.id
          }
        },
        update: {},
        create: {
          userId: owner.id,
          branchId: branch.id
        }
      })
    )
  );

  const internalUsers = [
    {
      email: "gerente@deliveryreg.local",
      name: "Gerente",
      role: "MANAGER" as const,
      branches
    },
    {
      email: "atendente-centro@deliveryreg.local",
      name: "Atendente Centro",
      role: "ATTENDANT" as const,
      branches: branches.filter((branch) => branch.name === "Centro")
    },
    {
      email: "entregador-centro@deliveryreg.local",
      name: "Entregador Centro",
      role: "DELIVERY" as const,
      branches: branches.filter((branch) => branch.name === "Centro")
    },
    {
      email: "entregador-ponta-negra@deliveryreg.local",
      name: "Entregador Ponta Negra",
      role: "DELIVERY" as const,
      branches: branches.filter((branch) => branch.name === "Ponta Negra")
    }
  ];

  for (const userDefinition of internalUsers) {
    const user = await prisma.user.upsert({
      where: {
        businessId_email: {
          businessId: business.id,
          email: userDefinition.email
        }
      },
      update: {
        isActive: true,
        role: userDefinition.role
      },
      create: {
        businessId: business.id,
        email: userDefinition.email,
        name: userDefinition.name,
        role: userDefinition.role,
        passwordHash: await hashPassword("troque-esta-senha")
      }
    });

    await Promise.all(
      userDefinition.branches.map((branch) =>
        prisma.userBranchAccess.upsert({
          where: {
            userId_branchId: {
              userId: user.id,
              branchId: branch.id
            }
          },
          update: {},
          create: {
            userId: user.id,
            branchId: branch.id
          }
        })
      )
    );
  }

  const category = await prisma.productCategory.upsert({
    where: {
      businessId_slug: {
        businessId: business.id,
        slug: "queijos"
      }
    },
    update: {
      isActive: true
    },
    create: {
      businessId: business.id,
      name: "Queijos",
      slug: "queijos",
      description: "Produtos vendidos por peso e separados na loja",
      sortOrder: 1
    }
  });

  const product = await prisma.product.upsert({
    where: {
      businessId_slug: {
        businessId: business.id,
        slug: "queijo-regional"
      }
    },
    update: {
      isActive: true
    },
    create: {
      businessId: business.id,
      categoryId: category.id,
      name: "Queijo regional",
      slug: "queijo-regional",
      description: "Peça o peso desejado e pague pelo peso real separado na unidade.",
      measurementType: "WEIGHT",
      baseUnit: "GRAM",
      sellingIncrement: 50,
      minimumOrderQuantity: 250,
      isActive: true
    }
  });

  const activePrice = await prisma.productPrice.findFirst({
    where: {
      businessId: business.id,
      productId: product.id,
      endsAt: null
    }
  });

  if (!activePrice) {
    await prisma.productPrice.create({
      data: {
        businessId: business.id,
        productId: product.id,
        priceCents: 4200,
        basisQuantity: 1000,
        basisUnit: "GRAM"
      }
    });
  }

  await Promise.all(
    branches.map((branch) =>
      prisma.productBranchAvailability.upsert({
        where: {
          businessId_branchId_productId: {
            businessId: business.id,
            branchId: branch.id,
            productId: product.id
          }
        },
        update: {
          isAvailable: true
        },
        create: {
          businessId: business.id,
          branchId: branch.id,
          productId: product.id,
          isAvailable: true
        }
      })
    )
  );

  const sourceDefinitions = [
    { code: "qr-centro-01", label: "QR Code Centro 01", branchName: "Centro" },
    { code: "qr-centro-02", label: "QR Code Centro 02", branchName: "Centro" },
    { code: "qr-ponta-negra-01", label: "QR Code Ponta Negra 01", branchName: "Ponta Negra" },
    { code: "qr-ponta-negra-02", label: "QR Code Ponta Negra 02", branchName: "Ponta Negra" },
    { code: "balcao", label: "Balcão" },
    { code: "embalagem", label: "Embalagem" },
    { code: "instagram", label: "Instagram" },
    { code: "whatsapp", label: "WhatsApp" }
  ];

  await Promise.all(
    sourceDefinitions.map((source) => {
      const branch = source.branchName
        ? branches.find((item) => item.name === source.branchName)
        : undefined;

      return prisma.leadSource.upsert({
        where: {
          businessId_code: {
            businessId: business.id,
            code: source.code
          }
        },
        update: {
          label: source.label,
          branchId: branch?.id,
          isActive: true
        },
        create: {
          businessId: business.id,
          branchId: branch?.id,
          code: source.code,
          label: source.label
        }
      });
    })
  );

  await Promise.all(
    branches.flatMap((branch) =>
      ["Centro", "Adrianopolis", "Ponta Negra"].map((zoneName) =>
        prisma.deliveryZone.upsert({
          where: {
            businessId_branchId_normalizedName: {
              businessId: business.id,
              branchId: branch.id,
              normalizedName: zoneName.toLowerCase().replace(/\s+/g, "-")
            }
          },
          update: {
            isActive: true,
            feeCents: 800,
            minimumOrderCents: 3000
          },
          create: {
            businessId: business.id,
            branchId: branch.id,
            name: zoneName,
            normalizedName: zoneName.toLowerCase().replace(/\s+/g, "-"),
            feeCents: 800,
            minimumOrderCents: 3000
          }
        })
      )
    )
  );
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (error) => {
    console.error(error);
    await prisma.$disconnect();
    process.exit(1);
  });
