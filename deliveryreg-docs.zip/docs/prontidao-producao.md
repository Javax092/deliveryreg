# Prontidão operacional para piloto controlado

## Configuração obrigatória

- `DATABASE_URL`: URL PostgreSQL de produção ou homologação.
- `AUTH_SECRET`: segredo aleatório com no mínimo 32 caracteres. Não expor no cliente.
- `BUSINESS_TIMEZONE`: deve ser `America/Manaus`.
- `NODE_ENV`: `production` em produção.

O deploy deve falhar se qualquer variável obrigatória estiver ausente.

## Matriz de autorização

| Capacidade | OWNER | MANAGER | ATTENDANT | DELIVERY |
| --- | --- | --- | --- | --- |
| Admin | permitido | limitado | negado | negado |
| Produtos | permitido | permitido conforme operação | leitura operacional | negado |
| Preços | permitido | permitido conforme operação | negado | negado |
| PDV | permitido | permitido | permitido | negado |
| Pedidos | permitido | permitido | operacional | somente entregas atribuídas |
| Estoque | permitido | permitido | leitura limitada | negado |
| Ajustar estoque | permitido | permitido | negado | negado |
| Clientes | permitido | permitido | mínimo necessário para pedido | negado |
| Gestão de delivery | permitido | permitido | limitado | somente atribuídas |
| Relatórios | permitido | permitido | limitado | negado |

`OWNER` e `MANAGER` são papéis de escopo empresarial. `ATTENDANT` e `DELIVERY` devem respeitar as filiais em `UserBranchAccess`.

## Autenticação

- Senhas são armazenadas com bcrypt.
- Sessões usam token aleatório, cookie `httpOnly`, `sameSite=lax`, `secure` em produção e expiração.
- Logout revoga a sessão no banco e expira o cookie.
- Usuários desativados não autenticam e sessões existentes deixam de ser aceitas.
- Não registrar senhas, cookies, tokens ou segredos em logs.
- Formulários internos dependem de cookie `sameSite=lax` e server actions. Para exposição pública maior, adicionar token CSRF por formulário antes de ampliar o piloto.

## Migrations

Procedimento:

1. Fazer backup do banco.
2. Aplicar `npx prisma migrate deploy`.
3. Executar verificação de saúde.
4. Validar login interno e catálogo público.

Nunca usar `prisma db push` em produção.

## Backup e restauração

Recomendação mínima para piloto:

- backup diário com `pg_dump`;
- backup manual antes de cada migration;
- retenção de pelo menos 7 dias;
- teste de restauração em banco separado antes de depender do procedimento.

Exemplo de backup:

```bash
pg_dump "$DATABASE_URL" --format=custom --file=backup-deliveryreg.dump
```

Exemplo de restore em banco novo:

```bash
pg_restore --dbname "$DATABASE_URL_RESTORE" --clean --if-exists backup-deliveryreg.dump
```

Rollback:

- erro antes de migration: abortar deploy;
- erro depois de migration sem escrita comercial relevante: restaurar backup;
- erro depois de vendas reais: pausar operação, exportar pedidos/movimentos recentes, decidir correção forward ou restore assistido.

## Bootstrap de produção

Não usar credenciais do seed em produção.

Procedimento seguro:

1. Criar empresa.
2. Criar Filial 1.
3. Criar Filial 2.
4. Criar OWNER inicial com senha gerada de forma segura no momento da implantação.
5. Exigir troca de senha operacional conforme política da empresa.
6. Criar MANAGER, ATTENDANT e DELIVERY necessários com acesso explícito por filial.

## QR por filial

Convenção:

- Filial Centro: `/catalogo?source=qr-centro-01`
- Filial Ponta Negra: `/catalogo?source=qr-ponta-negra-01`

Cada unidade física deve ter códigos independentes. Quando o domínio final existir, gerar QR apontando para:

```text
https://DOMINIO/catalogo?source=CODIGO_DA_UNIDADE
```

## Observabilidade do piloto

Monitorar diariamente:

- falhas de login;
- falhas de criação/conclusão de pedido;
- conflitos de estoque;
- falhas de delivery;
- exceções inesperadas.

Guia rápido para operador:

- Sessão expirada: entrar novamente.
- Pedido já finalizado: atualizar tela antes de tentar de novo.
- Estoque insuficiente: conferir saldo e registrar ajuste apenas se autorizado.
- Entrega sem entregador: gestor deve atribuir entregador ativo da filial.
- Erro persistente: anotar horário, usuário, pedido e ação realizada; acionar suporte técnico sem compartilhar senha.

## Sprint 9 — E2E Production Gate

Ambiente utilizado:

- Next.js em build de produção via `next build` e `next start`.
- Playwright `1.62.1`.
- Navegador: Chromium `151.0.7922.34`.
- PostgreSQL real em banco isolado `deliveryreg_e2e`.
- Banco preparado por `npm run test:e2e:setup`, com `prisma migrate deploy` e seed E2E determinístico.
- Não houve CI configurado no repositório; execução documentada para ambiente local/homologação.

Comandos para reproduzir:

```bash
npm run test:e2e:setup
npm run test:e2e
npm run lint
npm run typecheck
npm test
npm run test:postgres
npx prisma validate
npm run build
```

Testes Playwright:

- Total: 13.
- Aprovados: 13.
- Falhos: 0.
- Browser artifacts configurados: trace, screenshot e vídeo retidos em falha.

Jornadas validadas:

- Catálogo público por QR E2E usando `origem=qr-e2e-a1`.
- Produto por unidade, carrinho, checkout e criação de pedido.
- Produto por peso com preço de R$ 42/kg, solicitado 500 g, peso real 518 g, estimado R$ 21,00 e final R$ 21,76.
- Login válido, login inválido, logout, sessão revogada e usuário inativo.
- RBAC para OWNER, MANAGER, ATTENDANT e DELIVERY.
- Isolamento de filial para usuário operacional restrito à A1.
- Isolamento multiempresa contra recurso da Business B.
- PDV com pagamento PIX e baixa de estoque.
- Estoque insuficiente no PDV.
- Proteção contra duplicidade por refresh após conclusão.
- Delivery com atribuição, reatribuição, visibilidade por courier e auditoria `DELIVERY_ASSIGNED`/`DELIVERY_REASSIGNED`.
- Mobile público em 360px, 390px e 430px sem overflow horizontal.

Bugs encontrados e corrigidos:

- Páginas operacionais exibiam opções/dados de filiais fora do escopo para usuários restritos; corrigido filtro por `branchIds` em operação, PDV e estoque.
- Acesso administrativo sem sessão/revogado não tinha redirecionamento comum antes das páginas internas; adicionado layout do grupo administrativo para redirecionar autenticação ausente/revogada para `/login`.

Pendências:

- Criar workflow de CI para executar Playwright e publicar artifacts de falha.
- Melhorar UX de erro em Server Actions administrativas negativas; hoje o bloqueio ocorre no servidor, mas a apresentação visual ainda depende do erro padrão do Next.js em algumas tentativas não autorizadas.

Resultado final:

- `lint`: PASS.
- `typecheck`: PASS.
- unit/contrato: 34/34 PASS.
- PostgreSQL integração/concorrência: 9/9 PASS.
- Prisma validate: PASS.
- build de produção: PASS.
- E2E Playwright: 13/13 PASS.

Classificação Sprint 9: GREEN.

## Sprint 10 — Compatibilidade de QR público

Retomada aplicada:

- Catálogo público aceita `?source=CODIGO_DA_UNIDADE` e `?origem=CODIGO_DA_UNIDADE`.
- `origem` permanece como parâmetro canônico nas navegações internas entre catálogo, busca e produto.
- Quando os dois parâmetros são enviados, `origem` tem precedência.
- E2E público principal entra pelo formato documentado `source`.

Validações executadas:

- `npm test`: PASS, 35/35 testes unitários/contrato ativos.
- `npm run typecheck`: PASS.
- `npm run lint`: PASS.
- `npm run build`: PASS com variáveis obrigatórias definidas para ambiente local.

Pendências remanescentes:

- Criar workflow de CI para executar Playwright e publicar artifacts de falha.
- Melhorar UX de erro em Server Actions administrativas negativas.
