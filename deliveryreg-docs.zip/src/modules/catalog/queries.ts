import { prisma } from "@/db/prisma";

export async function listAdminProducts(businessId: string) {
  return prisma.product.findMany({
    where: {
      businessId
    },
    include: {
      category: true,
      prices: {
        where: {
          endsAt: null
        },
        orderBy: {
          startsAt: "desc"
        },
        take: 1
      },
      availability: {
        include: {
          branch: true
        },
        orderBy: {
          branch: {
            name: "asc"
          }
        }
      }
    },
    orderBy: {
      name: "asc"
    }
  });
}

export async function listAdminCategories(businessId: string) {
  return prisma.productCategory.findMany({
    where: {
      businessId
    },
    orderBy: [
      {
        sortOrder: "asc"
      },
      {
        name: "asc"
      }
    ]
  });
}
