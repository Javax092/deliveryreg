import { prisma } from "@/db/prisma";

export async function getManagementDashboard(input: {
  businessId: string;
  from: Date;
  to: Date;
}) {
  const [orders, analyticsEvents, branches] = await Promise.all([
    prisma.order.findMany({
      where: {
        businessId: input.businessId,
        createdAt: {
          gte: input.from,
          lte: input.to
        }
      },
      select: {
        branchId: true,
        status: true,
        salesChannel: true,
        totalCents: true,
        items: {
          select: {
            productNameSnapshot: true,
            measurementTypeSnapshot: true,
            requestedQuantity: true,
            actualQuantity: true,
            estimatedAmountCents: true,
            finalAmountCents: true
          }
        }
      }
    }),
    prisma.analyticsEvent.groupBy({
      by: ["eventType"],
      where: {
        businessId: input.businessId,
        occurredAt: {
          gte: input.from,
          lte: input.to
        }
      },
      _count: true
    }),
    prisma.branch.findMany({
      where: {
        businessId: input.businessId
      },
      select: {
        id: true,
        name: true
      },
      orderBy: {
        name: "asc"
      }
    })
  ]);

  const completed = orders.filter((order) => order.status === "COMPLETED");
  const revenueCents = completed.reduce((total, order) => total + order.totalCents, 0);
  const digitalRevenueCents = completed
    .filter((order) => order.salesChannel === "DIGITAL")
    .reduce((total, order) => total + order.totalCents, 0);
  const posRevenueCents = completed
    .filter((order) => order.salesChannel === "POS")
    .reduce((total, order) => total + order.totalCents, 0);
  const soldWeightGrams = completed.reduce(
    (total, order) =>
      total +
      order.items
        .filter((item) => item.measurementTypeSnapshot === "WEIGHT")
        .reduce((itemTotal, item) => itemTotal + (item.actualQuantity ?? item.requestedQuantity), 0),
    0
  );

  const branchComparisons = branches.map((branch) => {
    const branchOrders = completed.filter((order) => order.branchId === branch.id);
    const branchRevenueCents = branchOrders.reduce((total, order) => total + order.totalCents, 0);

    return {
      branchId: branch.id,
      name: branch.name,
      orders: branchOrders.length,
      revenueCents: branchRevenueCents
    };
  });

  const productMap = new Map<string, { quantity: number; revenueCents: number }>();

  for (const order of completed) {
    for (const item of order.items) {
      const current = productMap.get(item.productNameSnapshot) ?? {
        quantity: 0,
        revenueCents: 0
      };
      current.quantity += item.actualQuantity ?? item.requestedQuantity;
      current.revenueCents += item.finalAmountCents ?? item.estimatedAmountCents;
      productMap.set(item.productNameSnapshot, current);
    }
  }

  const products = [...productMap.entries()]
    .map(([name, totals]) => ({ name, ...totals }))
    .sort((a, b) => b.revenueCents - a.revenueCents)
    .slice(0, 10);

  return {
    period: {
      from: input.from,
      to: input.to
    },
    sales: {
      revenueCents,
      orders: completed.length,
      averageTicketCents: completed.length > 0 ? Math.round(revenueCents / completed.length) : null,
      soldWeightGrams,
      digitalRevenueCents,
      posRevenueCents
    },
    branches: branchComparisons,
    products,
    funnel: Object.fromEntries(
      analyticsEvents.map((event) => [event.eventType, event._count])
    ) as Record<string, number>
  };
}
