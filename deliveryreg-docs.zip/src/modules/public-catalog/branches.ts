import { prisma } from "@/db/prisma";
import { getDefaultPublicBusiness } from "@/modules/public-catalog/queries";

export async function listPublicBranches() {
  const business = await getDefaultPublicBusiness();

  if (!business) {
    return [];
  }

  return prisma.branch.findMany({
    where: {
      businessId: business.id,
      isActive: true
    },
    select: {
      id: true,
      name: true
    },
    orderBy: {
      name: "asc"
    }
  });
}
