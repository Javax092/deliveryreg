import { prisma } from "@/db/prisma";
import { resolveLeadSource } from "@/modules/leads/source";

export async function getDefaultPublicBusiness() {
  return prisma.business.findFirst({
    select: {
      id: true
    },
    orderBy: {
      createdAt: "asc"
    }
  });
}

export async function getPublicCatalog(input: {
  sourceCode?: string | null;
  search?: string | null;
}) {
  const business = await getDefaultPublicBusiness();

  if (!business) {
    return null;
  }

  const source = await resolveLeadSource({
    businessId: business.id,
    sourceCode: input.sourceCode
  });
  const branchId = source?.branchId ?? undefined;
  const search = input.search?.trim();

  const categories = await prisma.productCategory.findMany({
    where: {
      businessId: business.id,
      isActive: true,
      products: {
        some: {
          businessId: business.id,
          isActive: true,
          ...(search
            ? {
                OR: [
                  {
                    name: {
                      contains: search,
                      mode: "insensitive" as const
                    }
                  },
                  {
                    description: {
                      contains: search,
                      mode: "insensitive" as const
                    }
                  }
                ]
              }
            : {}),
          availability: branchId
            ? {
                some: {
                  branchId,
                  isAvailable: true
                }
              }
            : {
                some: {
                  isAvailable: true
                }
              }
        }
      }
    },
    select: {
      id: true,
      name: true,
      slug: true,
      products: {
        where: {
          businessId: business.id,
          isActive: true,
          ...(search
            ? {
                OR: [
                  {
                    name: {
                      contains: search,
                      mode: "insensitive" as const
                    }
                  },
                  {
                    description: {
                      contains: search,
                      mode: "insensitive" as const
                    }
                  }
                ]
              }
            : {}),
          availability: branchId
            ? {
                some: {
                  branchId,
                  isAvailable: true
                }
              }
            : {
                some: {
                  isAvailable: true
                }
              }
        },
        select: {
          id: true,
          name: true,
          slug: true,
          description: true,
          prices: {
            where: {
              endsAt: null
            },
            select: {
              priceCents: true,
              basisQuantity: true,
              basisUnit: true
            },
            orderBy: {
              startsAt: "desc"
            },
            take: 1
          }
        },
        orderBy: {
          name: "asc"
        }
      }
    },
    orderBy: [
      {
        sortOrder: "asc"
      },
      {
        name: "asc"
      }
    ]
  });

  return {
    business,
    source,
    branchId,
    categories
  };
}

export async function getPublicProduct(input: {
  slug: string;
  sourceCode?: string | null;
}) {
  const business = await getDefaultPublicBusiness();

  if (!business) {
    return null;
  }

  const source = await resolveLeadSource({
    businessId: business.id,
    sourceCode: input.sourceCode
  });
  const branchId = source?.branchId ?? undefined;

  const product = await prisma.product.findFirst({
    where: {
      businessId: business.id,
      slug: input.slug,
      isActive: true,
      availability: branchId
        ? {
            some: {
              branchId,
              isAvailable: true
            }
          }
        : {
            some: {
              isAvailable: true
            }
          }
    },
    select: {
      id: true,
      name: true,
      slug: true,
      description: true,
      measurementType: true,
      sellingIncrement: true,
      minimumOrderQuantity: true,
      category: {
        select: {
          name: true
        }
      },
      prices: {
        where: {
          endsAt: null
        },
        select: {
          priceCents: true,
          basisQuantity: true,
          basisUnit: true
        },
        orderBy: {
          startsAt: "desc"
        },
        take: 1
      }
    }
  });

  return {
    business,
    source,
    branchId,
    product
  };
}
