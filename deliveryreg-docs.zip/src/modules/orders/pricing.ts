import { calculateProportionalAmountCents } from "@/modules/shared/money/money";
import { validateSellingQuantity } from "@/modules/shared/quantity/measurement";

export type PricedOrderItemInput = {
  productId: string;
  productName: string;
  measurementType: "WEIGHT" | "UNIT" | "PACKAGE" | "VOLUME" | "BOX";
  requestedQuantity: number;
  actualQuantity?: number;
  sellingIncrement: number;
  minimumOrderQuantity: number;
  priceCents: number;
  priceBasisQuantity: number;
  priceBasisUnit: "GRAM" | "UNIT" | "PACKAGE" | "MILLILITER" | "BOX";
};

export type PricedOrderItem = {
  productId: string;
  productNameSnapshot: string;
  measurementTypeSnapshot: PricedOrderItemInput["measurementType"];
  requestedQuantity: number;
  actualQuantity: number | null;
  priceCentsSnapshot: number;
  priceBasisQuantitySnapshot: number;
  priceBasisUnitSnapshot: PricedOrderItemInput["priceBasisUnit"];
  estimatedAmountCents: number;
  finalAmountCents: number | null;
};

export function priceOrderItem(input: PricedOrderItemInput): PricedOrderItem {
  const requestedQuantity = validateSellingQuantity({
    quantity: input.requestedQuantity,
    minimumQuantity: input.minimumOrderQuantity,
    increment: input.sellingIncrement
  });

  const estimatedAmountCents = calculateProportionalAmountCents({
    priceCents: input.priceCents,
    basisQuantity: input.priceBasisQuantity,
    quantity: requestedQuantity
  });

  const actualQuantity = input.actualQuantity ?? null;
  const finalAmountCents =
    actualQuantity === null
      ? null
      : calculateProportionalAmountCents({
          priceCents: input.priceCents,
          basisQuantity: input.priceBasisQuantity,
          quantity: actualQuantity
        });

  return {
    productId: input.productId,
    productNameSnapshot: input.productName,
    measurementTypeSnapshot: input.measurementType,
    requestedQuantity,
    actualQuantity,
    priceCentsSnapshot: input.priceCents,
    priceBasisQuantitySnapshot: input.priceBasisQuantity,
    priceBasisUnitSnapshot: input.priceBasisUnit,
    estimatedAmountCents,
    finalAmountCents
  };
}
