import { prisma } from "@/db/prisma";
import type { StockMovementType } from "@/modules/inventory/ledger";
import { summarizeInventory } from "@/modules/inventory/ledger";

export async function listInventoryBalances(input: {
  businessId: string;
  branchId?: string;
}) {
  const [products, movementTotals] = await Promise.all([
    prisma.product.findMany({
      where: {
        businessId: input.businessId,
        isActive: true
      },
      select: {
        id: true,
        name: true
      },
      orderBy: {
        name: "asc"
      }
    }),
    prisma.stockMovement.groupBy({
      by: ["productId", "type"],
      where: {
        businessId: input.businessId,
        branchId: input.branchId
      },
      _sum: {
        quantityDelta: true
      }
    })
  ]);

  const movementsByProduct = new Map<
    string,
    Array<{ type: StockMovementType; quantityDelta: number }>
  >();

  for (const total of movementTotals) {
    const movements = movementsByProduct.get(total.productId) ?? [];
    movements.push({
      type: total.type,
      quantityDelta: total._sum.quantityDelta ?? 0
    });
    movementsByProduct.set(total.productId, movements);
  }

  return products.map((product) => ({
    product,
    summary: summarizeInventory(movementsByProduct.get(product.id) ?? [])
  }));
}
