"use client";

import { useEffect, useMemo, useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";

import { formatBRL } from "@/modules/shared/money/money";

type Branch = {
  id: string;
  name: string;
};

type CartItem = {
  productId: string;
  productName: string;
  sourceCode?: string;
  measurementType: "WEIGHT" | "UNIT" | "PACKAGE" | "VOLUME" | "BOX";
  requestedQuantity: number;
  estimatedAmountCents: number;
};

export function CartCheckout({ branches }: { branches: Branch[] }) {
  const router = useRouter();
  const [items, setItems] = useState<CartItem[]>(() => {
    if (typeof window === "undefined") {
      return [];
    }

    return JSON.parse(window.localStorage.getItem("deliveryreg_cart") ?? "[]") as CartItem[];
  });
  const [branchId, setBranchId] = useState(branches[0]?.id ?? "");
  const [name, setName] = useState("");
  const [whatsapp, setWhatsapp] = useState("");
  const [fulfillmentType, setFulfillmentType] = useState<"PICKUP" | "DELIVERY">("PICKUP");
  const [street, setStreet] = useState("");
  const [number, setNumber] = useState("");
  const [neighborhood, setNeighborhood] = useState("");
  const [reference, setReference] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    void fetch("/api/analytics", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        eventType: "cart_viewed",
        sourceCode: items[0]?.sourceCode
      })
    });
  }, [items]);

  const totalCents = useMemo(
    () => items.reduce((total, item) => total + item.estimatedAmountCents, 0),
    [items]
  );

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsSubmitting(true);
    setMessage(null);

    await fetch("/api/analytics", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        eventType: "checkout_started",
        sourceCode: items[0]?.sourceCode
      })
    });

    const response = await fetch("/api/orders", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        branchId,
        fulfillmentType,
        address:
          fulfillmentType === "DELIVERY"
            ? {
                street,
                number,
                neighborhood,
                reference
              }
            : undefined,
        sourceCode: items[0]?.sourceCode,
        idempotencyKey: window.crypto.randomUUID(),
        customer: {
          name,
          whatsapp
        },
        items: items.map((item) => ({
          productId: item.productId,
          requestedQuantity: item.requestedQuantity
        }))
      })
    });

    setIsSubmitting(false);

    if (!response.ok) {
      setMessage("Não foi possível criar seu pedido. Confira os dados e tente novamente.");
      return;
    }

    const payload = (await response.json()) as { orderId: string };
    window.localStorage.removeItem("deliveryreg_cart");
    router.push(`/pedido/${payload.orderId}`);
  }

  function removeItem(productId: string) {
    const next = items.filter((item) => item.productId !== productId);
    setItems(next);
    window.localStorage.setItem("deliveryreg_cart", JSON.stringify(next));
  }

  if (items.length === 0) {
    return (
      <div className="rounded-lg border border-slate-200 bg-white p-5 text-slate-700">
        Seu carrinho está vazio.
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <section className="space-y-3">
        {items.map((item) => (
          <article className="rounded-lg border border-slate-200 bg-white p-4" key={item.productId}>
            <div className="flex items-start justify-between gap-3">
              <div>
                <h2 className="font-semibold text-slate-950">{item.productName}</h2>
                <p className="mt-1 text-sm text-slate-600">
                  Solicitado: {item.requestedQuantity}
                  {item.measurementType === "WEIGHT" ? " g" : " un."}
                </p>
              </div>
              <button
                className="min-h-10 rounded-md px-3 text-sm font-semibold text-red-700"
                onClick={() => removeItem(item.productId)}
                type="button"
              >
                Remover
              </button>
            </div>
            <p className="mt-3 font-semibold text-emerald-800">
              Estimativa: {formatBRL(item.estimatedAmountCents)}
            </p>
          </article>
        ))}
      </section>

      <section className="rounded-lg border border-slate-200 bg-white p-4">
        <p className="text-sm text-slate-600">Total estimado</p>
        <p className="text-3xl font-semibold text-slate-950">{formatBRL(totalCents)}</p>
        <p className="mt-2 text-sm text-slate-600">
          Produtos por peso podem variar um pouco após a pesagem. Você paga pelo peso real
          separado na loja.
        </p>
      </section>

      <form className="space-y-4 rounded-lg border border-slate-200 bg-white p-4" onSubmit={submit}>
        <div>
          <label className="block text-sm font-medium text-slate-800" htmlFor="fulfillmentType">
            Como você quer receber
          </label>
          <select
            className="mt-1 h-12 w-full rounded-md border border-slate-300 px-3 text-base"
            id="fulfillmentType"
            value={fulfillmentType}
            onChange={(event) => setFulfillmentType(event.target.value as "PICKUP" | "DELIVERY")}
          >
            <option value="PICKUP">Retirar na unidade</option>
            <option value="DELIVERY">Receber por entrega</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-800" htmlFor="branch">
            Unidade responsável
          </label>
          <select
            className="mt-1 h-12 w-full rounded-md border border-slate-300 px-3 text-base"
            id="branch"
            required
            value={branchId}
            onChange={(event) => setBranchId(event.target.value)}
          >
            {branches.map((branch) => (
              <option key={branch.id} value={branch.id}>
                {branch.name}
              </option>
            ))}
          </select>
        </div>
        {fulfillmentType === "DELIVERY" ? (
          <div className="space-y-3 rounded-md bg-slate-50 p-3">
            <p className="text-sm font-medium text-slate-800">
              A entrega depende da área atendida e do pedido mínimo.
            </p>
            <input
              className="h-12 w-full rounded-md border border-slate-300 px-3 text-base"
              placeholder="Rua"
              required
              value={street}
              onChange={(event) => setStreet(event.target.value)}
            />
            <input
              className="h-12 w-full rounded-md border border-slate-300 px-3 text-base"
              placeholder="Número"
              required
              value={number}
              onChange={(event) => setNumber(event.target.value)}
            />
            <input
              className="h-12 w-full rounded-md border border-slate-300 px-3 text-base"
              placeholder="Bairro"
              required
              value={neighborhood}
              onChange={(event) => setNeighborhood(event.target.value)}
            />
            <input
              className="h-12 w-full rounded-md border border-slate-300 px-3 text-base"
              placeholder="Referência"
              value={reference}
              onChange={(event) => setReference(event.target.value)}
            />
          </div>
        ) : null}
        <div>
          <label className="block text-sm font-medium text-slate-800" htmlFor="name">
            Seu nome
          </label>
          <input
            className="mt-1 h-12 w-full rounded-md border border-slate-300 px-3 text-base"
            id="name"
            required
            value={name}
            onChange={(event) => setName(event.target.value)}
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-800" htmlFor="whatsapp">
            WhatsApp
          </label>
          <input
            className="mt-1 h-12 w-full rounded-md border border-slate-300 px-3 text-base"
            id="whatsapp"
            inputMode="tel"
            required
            value={whatsapp}
            onChange={(event) => setWhatsapp(event.target.value)}
          />
        </div>
        <button
          className="h-12 w-full rounded-md bg-emerald-700 px-4 font-semibold text-white disabled:bg-slate-400"
          disabled={isSubmitting || !branchId}
          type="submit"
        >
          {isSubmitting ? "Criando pedido..." : "Fazer pedido para retirada"}
        </button>
        {message ? (
          <p className="text-sm font-medium text-red-700" role="alert">
            {message}
          </p>
        ) : null}
      </form>
    </div>
  );
}
