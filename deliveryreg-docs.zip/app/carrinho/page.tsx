import Link from "next/link";

import { CartCheckout } from "@/components/public/CartCheckout";
import { listPublicBranches } from "@/modules/public-catalog/branches";

export const dynamic = "force-dynamic";

export default async function CarrinhoPage() {
  const branches = await listPublicBranches();

  return (
    <main className="min-h-screen bg-slate-50">
      <section className="mx-auto max-w-lg px-5 py-5">
        <Link className="text-sm font-semibold text-emerald-800" href="/catalogo">
          Voltar ao catálogo
        </Link>
        <div className="mt-4">
          <h1 className="text-3xl font-semibold text-slate-950">Carrinho</h1>
          <p className="mt-2 text-slate-700">
            Confira a estimativa e escolha a unidade para retirada.
          </p>
        </div>
        <div className="mt-5">
          <CartCheckout branches={branches} />
        </div>
      </section>
    </main>
  );
}
