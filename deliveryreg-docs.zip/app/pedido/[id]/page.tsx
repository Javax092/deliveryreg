import Link from "next/link";
import { notFound } from "next/navigation";

import { prisma } from "@/db/prisma";
import { formatBRL } from "@/modules/shared/money/money";

export const dynamic = "force-dynamic";

type Props = {
  params: Promise<{
    id: string;
  }>;
};

const statusLabel = {
  CREATED: "Novo",
  ACCEPTED: "Aceito",
  PREPARING: "Em separação",
  READY: "Pronto",
  COMPLETED: "Finalizado",
  CANCELLED: "Cancelado"
};

export default async function PedidoPage({ params }: Props) {
  const { id } = await params;
  const order = await prisma.order.findUnique({
    where: {
      id
    },
    select: {
      status: true,
      totalCents: true,
      branch: {
        select: {
          name: true
        }
      },
      items: {
        select: {
          id: true,
          productNameSnapshot: true,
          measurementTypeSnapshot: true,
          requestedQuantity: true,
          estimatedAmountCents: true
        }
      }
    }
  });

  if (!order) {
    notFound();
  }

  return (
    <main className="min-h-screen bg-slate-50">
      <section className="mx-auto max-w-lg px-5 py-6">
        <h1 className="text-3xl font-semibold text-slate-950">Pedido recebido</h1>
        <p className="mt-2 text-slate-700">
          Retirada na unidade {order.branch.name}. Status:{" "}
          <strong>{statusLabel[order.status]}</strong>.
        </p>

        <section className="mt-5 rounded-lg border border-slate-200 bg-white p-4">
          <h2 className="font-semibold text-slate-950">Resumo</h2>
          <div className="mt-3 space-y-3">
            {order.items.map((item) => (
              <article className="border-t border-slate-100 pt-3" key={item.id}>
                <p className="font-medium text-slate-950">{item.productNameSnapshot}</p>
                <p className="text-sm text-slate-600">
                  Solicitado: {item.requestedQuantity}
                  {item.measurementTypeSnapshot === "WEIGHT" ? " g" : " un."}
                </p>
                <p className="text-sm font-semibold text-emerald-800">
                  Estimativa: {formatBRL(item.estimatedAmountCents)}
                </p>
              </article>
            ))}
          </div>
          <p className="mt-4 text-xl font-semibold text-slate-950">
            Total estimado: {formatBRL(order.totalCents)}
          </p>
          <p className="mt-2 text-sm text-slate-600">
            O valor de produtos por peso pode variar um pouco após a pesagem. Você paga pelo peso
            real separado na loja.
          </p>
        </section>

        <Link
          className="mt-5 flex h-12 items-center justify-center rounded-md bg-emerald-700 px-4 font-semibold text-white"
          href="/catalogo"
        >
          Voltar ao catálogo
        </Link>
      </section>
    </main>
  );
}
