import Link from "next/link";

import { AnalyticsPing } from "@/components/public/AnalyticsPing";
import { formatCatalogPrice } from "@/modules/catalog/product-domain";
import { resolvePublicSourceCode } from "@/modules/leads/source";
import { getPublicCatalog } from "@/modules/public-catalog/queries";

export const dynamic = "force-dynamic";

type Props = {
  searchParams: Promise<{
    origem?: string;
    source?: string;
    busca?: string;
  }>;
};

export default async function CatalogoPage({ searchParams }: Props) {
  const params = await searchParams;
  const sourceCode = resolvePublicSourceCode(params);
  const catalog = await getPublicCatalog({
    sourceCode,
    search: params.busca
  });

  if (!catalog) {
    return (
      <main className="mx-auto min-h-screen max-w-lg px-5 py-10">
        <h1 className="text-2xl font-semibold text-slate-950">Catálogo indisponível</h1>
        <p className="mt-2 text-slate-700">Tente novamente em alguns instantes.</p>
      </main>
    );
  }

  const sourceSuffix = sourceCode ? `?origem=${encodeURIComponent(sourceCode)}` : "";

  return (
    <main className="min-h-screen bg-slate-50">
      <AnalyticsPing eventType="catalog_viewed" sourceCode={sourceCode} />
      <section className="bg-emerald-800 px-5 pb-8 pt-6 text-white">
        <div className="mx-auto max-w-lg">
          <p className="text-sm font-semibold uppercase text-emerald-100">
            {catalog.source?.branch?.name ?? "Catálogo digital"}
          </p>
          <h1 className="mt-2 text-3xl font-semibold">Escolha seus produtos para comprar depois</h1>
          <p className="mt-3 text-emerald-50">
            Veja preços, disponibilidade e registre seu interesse sem criar conta.
          </p>
          <form className="mt-5" role="search">
            {sourceCode ? <input name="origem" type="hidden" value={sourceCode} /> : null}
            <label className="sr-only" htmlFor="busca">
              Buscar produto
            </label>
            <input
              className="h-12 w-full rounded-md border-0 px-4 text-base text-slate-950"
              defaultValue={params.busca}
              id="busca"
              name="busca"
              placeholder="Buscar produto"
            />
          </form>
        </div>
      </section>

      <section className="mx-auto max-w-lg px-5 py-6">
        {catalog.categories.length === 0 ? (
          <div className="rounded-lg border border-slate-200 bg-white p-5 text-slate-700">
            Nenhum produto disponível para esta unidade agora.
          </div>
        ) : (
          <div className="space-y-8">
            {catalog.categories.map((category) => (
              <section key={category.id}>
                <h2 className="text-xl font-semibold text-slate-950">{category.name}</h2>
                <div className="mt-3 space-y-3">
                  {category.products.map((product) => {
                    const price = product.prices[0];
                    return (
                      <Link
                        className="block rounded-lg border border-slate-200 bg-white p-4 shadow-sm"
                        href={`/produto/${product.slug}${sourceSuffix}`}
                        key={product.id}
                      >
                        <div className="flex gap-3">
                          <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-md bg-emerald-50 text-sm font-semibold text-emerald-800">
                            Produto
                          </div>
                          <div className="min-w-0">
                            <h3 className="font-semibold text-slate-950">{product.name}</h3>
                            {product.description ? (
                              <p className="mt-1 line-clamp-2 text-sm text-slate-600">
                                {product.description}
                              </p>
                            ) : null}
                            <p className="mt-2 font-semibold text-emerald-800">
                              {price
                                ? formatCatalogPrice({
                                    priceCents: price.priceCents,
                                    basisQuantity: price.basisQuantity,
                                    basisUnit: price.basisUnit
                                  })
                                : "Preço indisponível"}
                            </p>
                          </div>
                        </div>
                      </Link>
                    );
                  })}
                </div>
              </section>
            ))}
          </div>
        )}
      </section>
    </main>
  );
}
