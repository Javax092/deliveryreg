export default function Home() {
  return (
    <main className="mx-auto flex min-h-screen max-w-4xl flex-col justify-center px-6">
      <p className="text-sm font-semibold uppercase tracking-wide text-emerald-700">
        DeliveryReg
      </p>
      <h1 className="mt-3 text-4xl font-semibold text-slate-950">
        Fundação operacional pronta para catálogo, pedidos e unidades.
      </h1>
      <p className="mt-4 max-w-2xl text-lg leading-8 text-slate-700">
        Esta aplicação foi preparada para operar com multiempresa, controle de acesso,
        auditoria, dinheiro em centavos, quantidades normalizadas e histórico comercial
        preservado.
      </p>
    </main>
  );
}
