import Link from "next/link";
import { notFound } from "next/navigation";

import { AnalyticsPing } from "@/components/public/AnalyticsPing";
import { QuantityInterest } from "@/components/public/QuantityInterest";
import { formatCatalogPrice } from "@/modules/catalog/product-domain";
import { resolvePublicSourceCode } from "@/modules/leads/source";
import { getPublicProduct } from "@/modules/public-catalog/queries";

export const dynamic = "force-dynamic";

type Props = {
  params: Promise<{
    slug: string;
  }>;
  searchParams: Promise<{
    origem?: string;
    source?: string;
  }>;
};

export default async function ProdutoPage({ params, searchParams }: Props) {
  const [{ slug }, query] = await Promise.all([params, searchParams]);
  const sourceCode = resolvePublicSourceCode(query);
  const result = await getPublicProduct({
    slug,
    sourceCode
  });

  if (!result?.product) {
    notFound();
  }

  const product = result.product;
  const price = product.prices[0];

  if (!price) {
    notFound();
  }

  const catalogHref = sourceCode
    ? `/catalogo?origem=${encodeURIComponent(sourceCode)}`
    : "/catalogo";

  return (
    <main className="min-h-screen bg-slate-50">
      <AnalyticsPing eventType="product_viewed" productId={product.id} sourceCode={sourceCode} />
      <section className="mx-auto max-w-lg px-5 py-5">
        <Link className="text-sm font-semibold text-emerald-800" href={catalogHref}>
          Voltar ao catálogo
        </Link>
        <div className="mt-4 overflow-hidden rounded-lg bg-white shadow-sm">
          <div className="flex aspect-[4/3] items-center justify-center bg-emerald-50 text-emerald-900">
            Produto
          </div>
          <div className="p-4">
            <p className="text-sm font-semibold text-emerald-700">
              {product.category?.name ?? "Produto"}
            </p>
            <h1 className="mt-1 text-3xl font-semibold text-slate-950">{product.name}</h1>
            {product.description ? (
              <p className="mt-3 text-slate-700">{product.description}</p>
            ) : null}
            <p className="mt-4 text-2xl font-semibold text-emerald-800">
              {formatCatalogPrice({
                priceCents: price.priceCents,
                basisQuantity: price.basisQuantity,
                basisUnit: price.basisUnit
              })}
            </p>
          </div>
        </div>

        <QuantityInterest
          basisQuantity={price.basisQuantity}
          increment={product.sellingIncrement}
          measurementType={product.measurementType}
          minimumQuantity={product.minimumOrderQuantity}
          priceCents={price.priceCents}
          productId={product.id}
          productName={product.name}
          sourceCode={sourceCode}
        />
      </section>
    </main>
  );
}
