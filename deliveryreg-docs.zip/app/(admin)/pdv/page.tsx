import { finalizePosSale } from "./actions";
import { prisma } from "@/db/prisma";
import { formatCatalogPrice } from "@/modules/catalog/product-domain";
import { requirePermission } from "@/modules/shared/auth/permissions";

export const dynamic = "force-dynamic";

const paymentMethods = [
  { value: "PIX", label: "Pix" },
  { value: "DEBIT_CARD", label: "Cartão de débito" },
  { value: "CREDIT_CARD", label: "Cartão de crédito" },
  { value: "CASH", label: "Dinheiro" }
];

export default async function PdvPage() {
  const context = await requirePermission("orders:complete");
  const [branches, products] = await Promise.all([
    prisma.branch.findMany({
      where: {
        businessId: context.businessId,
        isActive: true,
        ...(context.role === "ATTENDANT" || context.role === "DELIVERY"
          ? {
              id: {
                in: context.branchIds
              }
            }
          : {})
      },
      select: {
        id: true,
        name: true
      },
      orderBy: { name: "asc" }
    }),
    prisma.product.findMany({
      where: {
        businessId: context.businessId,
        isActive: true
      },
      select: {
        id: true,
        name: true,
        prices: {
          where: { endsAt: null },
          select: {
            priceCents: true,
            basisQuantity: true,
            basisUnit: true
          },
          orderBy: { startsAt: "desc" },
          take: 1
        }
      },
      orderBy: { name: "asc" }
    })
  ]);

  return (
    <main className="min-h-screen bg-slate-100 px-4 py-6">
      <div className="mx-auto max-w-3xl">
        <h1 className="text-3xl font-semibold text-slate-950">PDV presencial</h1>
        <p className="mt-2 text-slate-700">
          Registre vendas feitas no balcão usando o mesmo histórico comercial e estoque.
        </p>

        <form action={finalizePosSale} className="mt-6 space-y-4 rounded-lg bg-white p-5">
          <input name="idempotencyKey" type="hidden" value={`pos-${crypto.randomUUID()}`} />
          <div>
            <label className="block text-sm font-medium text-slate-800" htmlFor="branchId">
              Unidade
            </label>
            <select
              className="mt-1 h-12 w-full rounded-md border border-slate-300 px-3"
              id="branchId"
              name="branchId"
              required
            >
              {branches.map((branch) => (
                <option key={branch.id} value={branch.id}>
                  {branch.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-800" htmlFor="productId">
              Produto
            </label>
            <select
              className="mt-1 h-12 w-full rounded-md border border-slate-300 px-3"
              id="productId"
              name="productId"
              required
            >
              {products.map((product) => {
                const price = product.prices[0];
                return (
                  <option key={product.id} value={product.id}>
                    {product.name}
                    {price
                      ? ` - ${formatCatalogPrice({
                          priceCents: price.priceCents,
                          basisQuantity: price.basisQuantity,
                          basisUnit: price.basisUnit
                        })}`
                      : ""}
                  </option>
                );
              })}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-800" htmlFor="quantity">
              Quantidade ou peso em unidade base
            </label>
            <input
              className="mt-1 h-12 w-full rounded-md border border-slate-300 px-3"
              id="quantity"
              min="1"
              name="quantity"
              required
              type="number"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-800" htmlFor="paymentMethod">
              Forma de pagamento
            </label>
            <select
              className="mt-1 h-12 w-full rounded-md border border-slate-300 px-3"
              id="paymentMethod"
              name="paymentMethod"
              required
            >
              {paymentMethods.map((method) => (
                <option key={method.value} value={method.value}>
                  {method.label}
                </option>
              ))}
            </select>
          </div>

          <button className="h-12 w-full rounded-md bg-emerald-700 font-semibold text-white">
            Finalizar venda
          </button>
        </form>
      </div>
    </main>
  );
}
