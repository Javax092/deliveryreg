"use server";

import { revalidatePath } from "next/cache";

import { createPosSale } from "@/modules/pos/create-pos-sale";
import { getCurrentUserContext } from "@/modules/shared/auth/permissions";

export async function finalizePosSale(formData: FormData) {
  const context = await getCurrentUserContext();

  await createPosSale({
    context,
    branchId: String(formData.get("branchId")),
    productId: String(formData.get("productId")),
    quantity: Number(formData.get("quantity")),
    paymentMethod: String(formData.get("paymentMethod")) as "CASH" | "PIX" | "DEBIT_CARD" | "CREDIT_CARD",
    idempotencyKey: String(formData.get("idempotencyKey"))
  });

  revalidatePath("/pdv");
  revalidatePath("/estoque");
}
