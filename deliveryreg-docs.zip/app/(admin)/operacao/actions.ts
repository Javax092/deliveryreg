"use server";

import { revalidatePath } from "next/cache";

import { completeOrder } from "@/modules/orders/complete-order";
import { confirmActualWeight, transitionOperationalOrder } from "@/modules/orders/operation";
import { getCurrentUserContext } from "@/modules/shared/auth/permissions";

export async function acceptOrder(formData: FormData) {
  const context = await getCurrentUserContext();
  await transitionOperationalOrder({
    context,
    orderId: String(formData.get("orderId")),
    toStatus: "ACCEPTED"
  });
  revalidatePath("/operacao");
}

export async function startPreparation(formData: FormData) {
  const context = await getCurrentUserContext();
  await transitionOperationalOrder({
    context,
    orderId: String(formData.get("orderId")),
    toStatus: "PREPARING"
  });
  revalidatePath("/operacao");
}

export async function markReady(formData: FormData) {
  const context = await getCurrentUserContext();
  await transitionOperationalOrder({
    context,
    orderId: String(formData.get("orderId")),
    toStatus: "READY"
  });
  revalidatePath("/operacao");
}

export async function cancelOrder(formData: FormData) {
  const context = await getCurrentUserContext();
  await transitionOperationalOrder({
    context,
    orderId: String(formData.get("orderId")),
    toStatus: "CANCELLED",
    reason: String(formData.get("reason") ?? "Cancelado pela operação")
  });
  revalidatePath("/operacao");
}

export async function completeOperationalOrder(formData: FormData) {
  const context = await getCurrentUserContext();
  await completeOrder({
    context,
    orderId: String(formData.get("orderId")),
    idempotencyKey: String(formData.get("idempotencyKey"))
  });
  revalidatePath("/operacao");
}

export async function confirmWeight(formData: FormData) {
  const context = await getCurrentUserContext();
  await confirmActualWeight({
    context,
    orderItemId: String(formData.get("orderItemId")),
    actualQuantity: Number(formData.get("actualQuantity")),
    idempotencyKey: String(formData.get("idempotencyKey"))
  });
  revalidatePath("/operacao");
}
