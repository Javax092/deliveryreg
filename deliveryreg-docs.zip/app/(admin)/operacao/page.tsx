import {
  acceptOrder,
  cancelOrder,
  completeOperationalOrder,
  confirmWeight,
  markReady,
  startPreparation
} from "./actions";
import { prisma } from "@/db/prisma";
import { formatBRL } from "@/modules/shared/money/money";
import { requirePermission } from "@/modules/shared/auth/permissions";

export const dynamic = "force-dynamic";

const columns = [
  { status: "CREATED", title: "Novos" },
  { status: "ACCEPTED", title: "Aceitos" },
  { status: "PREPARING", title: "Em separação" },
  { status: "READY", title: "Prontos" }
] as const;

export default async function OperacaoPage() {
  const context = await requirePermission("orders:read");
  const orders = await prisma.order.findMany({
    where: {
      businessId: context.businessId,
      ...(context.role === "ATTENDANT" || context.role === "DELIVERY"
        ? {
            branchId: {
              in: context.branchIds
            }
          }
        : {}),
      status: {
        in: columns.map((column) => column.status)
      }
    },
    select: {
      id: true,
      status: true,
      totalCents: true,
      branch: {
        select: {
          name: true
        }
      },
      customer: {
        select: {
          name: true
        }
      },
      items: {
        select: {
          id: true,
          productNameSnapshot: true,
          requestedQuantity: true,
          actualQuantity: true,
          measurementTypeSnapshot: true,
          estimatedAmountCents: true,
          finalAmountCents: true
        }
      }
    },
    orderBy: {
      createdAt: "asc"
    }
  });

  return (
    <main className="min-h-screen bg-slate-100 px-4 py-6">
      <div className="mx-auto max-w-7xl">
        <h1 className="text-3xl font-semibold text-slate-950">Operação da loja</h1>
        <p className="mt-2 text-slate-700">
          Acompanhe pedidos de retirada, confirme pesos reais e avance status.
        </p>

        <div className="mt-6 grid gap-4 lg:grid-cols-4">
          {columns.map((column) => (
            <section className="min-h-60 rounded-lg bg-white p-3" key={column.status}>
              <h2 className="font-semibold text-slate-950">{column.title}</h2>
              <div className="mt-3 space-y-3">
                {orders
                  .filter((order) => order.status === column.status)
                  .map((order) => (
                    <article className="rounded-md border border-slate-200 p-3" key={order.id}>
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h3 className="font-semibold text-slate-950">
                            Pedido #{order.id.slice(-6)}
                          </h3>
                          <p className="text-sm text-slate-600">{order.branch.name}</p>
                          <p className="text-sm text-slate-600">
                            {order.customer?.name ?? "Cliente não identificado"}
                          </p>
                        </div>
                        <p className="font-semibold text-emerald-800">{formatBRL(order.totalCents)}</p>
                      </div>

                      <div className="mt-3 space-y-3">
                        {order.items.map((item) => (
                          <div className="rounded-md bg-slate-50 p-2 text-sm" key={item.id}>
                            <p className="font-medium text-slate-950">{item.productNameSnapshot}</p>
                            <p>Solicitado: {item.requestedQuantity} g</p>
                            {item.actualQuantity ? (
                              <>
                                <p>Peso real: {item.actualQuantity} g</p>
                                <p>Valor final: {formatBRL(item.finalAmountCents ?? 0)}</p>
                              </>
                            ) : item.measurementTypeSnapshot === "WEIGHT" &&
                              order.status === "PREPARING" ? (
                              <form action={confirmWeight} className="mt-2 flex gap-2">
                                <input name="orderItemId" type="hidden" value={item.id} />
                                <input
                                  name="idempotencyKey"
                                  type="hidden"
                                  value={`confirm-weight-${item.id}`}
                                />
                                <label className="sr-only" htmlFor={`weight-${item.id}`}>
                                  Peso real
                                </label>
                                <input
                                  className="h-10 min-w-0 flex-1 rounded-md border border-slate-300 px-2"
                                  id={`weight-${item.id}`}
                                  min="1"
                                  name="actualQuantity"
                                  placeholder="Peso real"
                                  required
                                  type="number"
                                />
                                <button
                                  className="rounded-md bg-emerald-700 px-3 text-sm font-semibold text-white"
                                  type="submit"
                                >
                                  Confirmar
                                </button>
                              </form>
                            ) : null}
                            <p>Estimativa: {formatBRL(item.estimatedAmountCents)}</p>
                          </div>
                        ))}
                      </div>

                      <div className="mt-3 grid gap-2">
                        {order.status === "CREATED" ? (
                          <form action={acceptOrder}>
                            <input name="orderId" type="hidden" value={order.id} />
                            <button className="h-10 w-full rounded-md bg-emerald-700 font-semibold text-white">
                              Aceitar
                            </button>
                          </form>
                        ) : null}
                        {order.status === "ACCEPTED" ? (
                          <form action={startPreparation}>
                            <input name="orderId" type="hidden" value={order.id} />
                            <button className="h-10 w-full rounded-md bg-emerald-700 font-semibold text-white">
                              Iniciar separação
                            </button>
                          </form>
                        ) : null}
                        {order.status === "PREPARING" ? (
                          <form action={markReady}>
                            <input name="orderId" type="hidden" value={order.id} />
                            <button className="h-10 w-full rounded-md bg-emerald-700 font-semibold text-white">
                              Marcar pronto
                            </button>
                          </form>
                        ) : null}
                        {order.status === "READY" ? (
                          <form action={completeOperationalOrder}>
                            <input name="orderId" type="hidden" value={order.id} />
                            <input
                              name="idempotencyKey"
                              type="hidden"
                              value={`complete-order-${order.id}`}
                            />
                            <button className="h-10 w-full rounded-md bg-emerald-700 font-semibold text-white">
                              Finalizar
                            </button>
                          </form>
                        ) : null}
                        {order.status !== "READY" ? (
                          <form action={cancelOrder}>
                            <input name="orderId" type="hidden" value={order.id} />
                            <input name="reason" type="hidden" value="Cancelado pela operação" />
                            <button className="h-10 w-full rounded-md border border-red-300 font-semibold text-red-700">
                              Cancelar
                            </button>
                          </form>
                        ) : null}
                      </div>
                    </article>
                  ))}
              </div>
            </section>
          ))}
        </div>
      </div>
    </main>
  );
}
