"use server";

import { revalidatePath } from "next/cache";

import { adjustInventory, transferInventory } from "@/modules/inventory/operations";
import { getCurrentUserContext } from "@/modules/shared/auth/permissions";

export async function adjustStock(formData: FormData) {
  const context = await getCurrentUserContext();
  await adjustInventory({
    context,
    branchId: String(formData.get("branchId")),
    productId: String(formData.get("productId")),
    quantityDelta: Number(formData.get("quantityDelta")),
    reason: String(formData.get("reason"))
  });
  revalidatePath("/estoque");
}

export async function transferStock(formData: FormData) {
  const context = await getCurrentUserContext();
  await transferInventory({
    context,
    fromBranchId: String(formData.get("fromBranchId")),
    toBranchId: String(formData.get("toBranchId")),
    productId: String(formData.get("productId")),
    quantity: Number(formData.get("quantity")),
    reason: String(formData.get("reason"))
  });
  revalidatePath("/estoque");
}
