import { adjustStock, transferStock } from "./actions";
import { prisma } from "@/db/prisma";
import { listInventoryBalances } from "@/modules/inventory/queries";
import { requirePermission } from "@/modules/shared/auth/permissions";

export const dynamic = "force-dynamic";

export default async function EstoquePage() {
  const context = await requirePermission("inventory:read");
  const restrictedBranchId =
    context.role === "ATTENDANT" || context.role === "DELIVERY" ? context.branchIds[0] : undefined;
  const [branches, products, balances] = await Promise.all([
    prisma.branch.findMany({
      where: {
        businessId: context.businessId,
        isActive: true,
        ...(restrictedBranchId ? { id: restrictedBranchId } : {})
      },
      select: {
        id: true,
        name: true
      },
      orderBy: { name: "asc" }
    }),
    prisma.product.findMany({
      where: { businessId: context.businessId, isActive: true },
      select: {
        id: true,
        name: true
      },
      orderBy: { name: "asc" }
    }),
    listInventoryBalances({ businessId: context.businessId, branchId: restrictedBranchId })
  ]);

  return (
    <main className="min-h-screen bg-slate-100 px-4 py-6">
      <div className="mx-auto max-w-6xl">
        <h1 className="text-3xl font-semibold text-slate-950">Estoque</h1>
        <p className="mt-2 text-slate-700">
          Saldo calculado por movimentações: entradas, vendas, perdas, ajustes, transferências e
          devoluções.
        </p>

        <section className="mt-6 overflow-hidden rounded-lg bg-white">
          <div className="grid grid-cols-7 gap-3 bg-slate-200 px-4 py-3 text-sm font-semibold">
            <span>Produto</span>
            <span>Entrou</span>
            <span>Vendido</span>
            <span>Perda</span>
            <span>Transferido</span>
            <span>Ajuste</span>
            <span>Saldo</span>
          </div>
          {balances.map(({ product, summary }) => (
            <div className="grid grid-cols-7 gap-3 border-t border-slate-100 px-4 py-3 text-sm" key={product.id}>
              <span className="font-medium text-slate-950">{product.name}</span>
              <span>{summary.purchased + summary.returned}</span>
              <span>{summary.sold}</span>
              <span>{summary.lost}</span>
              <span>{summary.transferredIn - summary.transferredOut}</span>
              <span>{summary.adjusted}</span>
              <span className="font-semibold">{summary.current}</span>
            </div>
          ))}
        </section>

        <div className="mt-6 grid gap-4 lg:grid-cols-2">
          <form action={adjustStock} className="space-y-3 rounded-lg bg-white p-4">
            <h2 className="font-semibold text-slate-950">Ajuste de estoque</h2>
            <Selects branches={branches} products={products} />
            <input
              className="h-11 w-full rounded-md border border-slate-300 px-3"
              name="quantityDelta"
              placeholder="Quantidade (+ entrada, - saída)"
              required
              type="number"
            />
            <input
              className="h-11 w-full rounded-md border border-slate-300 px-3"
              name="reason"
              placeholder="Motivo"
              required
            />
            <button className="h-11 w-full rounded-md bg-emerald-700 font-semibold text-white">
              Registrar ajuste
            </button>
          </form>

          <form action={transferStock} className="space-y-3 rounded-lg bg-white p-4">
            <h2 className="font-semibold text-slate-950">Transferência</h2>
            <select className="h-11 w-full rounded-md border border-slate-300 px-3" name="fromBranchId">
              {branches.map((branch) => (
                <option key={branch.id} value={branch.id}>
                  Origem: {branch.name}
                </option>
              ))}
            </select>
            <select className="h-11 w-full rounded-md border border-slate-300 px-3" name="toBranchId">
              {branches.map((branch) => (
                <option key={branch.id} value={branch.id}>
                  Destino: {branch.name}
                </option>
              ))}
            </select>
            <select className="h-11 w-full rounded-md border border-slate-300 px-3" name="productId">
              {products.map((product) => (
                <option key={product.id} value={product.id}>
                  {product.name}
                </option>
              ))}
            </select>
            <input
              className="h-11 w-full rounded-md border border-slate-300 px-3"
              name="quantity"
              placeholder="Quantidade"
              required
              type="number"
            />
            <input
              className="h-11 w-full rounded-md border border-slate-300 px-3"
              name="reason"
              placeholder="Motivo"
              required
            />
            <button className="h-11 w-full rounded-md bg-emerald-700 font-semibold text-white">
              Transferir
            </button>
          </form>
        </div>
      </div>
    </main>
  );
}

function Selects({
  branches,
  products
}: {
  branches: Array<{ id: string; name: string }>;
  products: Array<{ id: string; name: string }>;
}) {
  return (
    <>
      <select className="h-11 w-full rounded-md border border-slate-300 px-3" name="branchId">
        {branches.map((branch) => (
          <option key={branch.id} value={branch.id}>
            {branch.name}
          </option>
        ))}
      </select>
      <select className="h-11 w-full rounded-md border border-slate-300 px-3" name="productId">
        {products.map((product) => (
          <option key={product.id} value={product.id}>
            {product.name}
          </option>
        ))}
      </select>
    </>
  );
}
