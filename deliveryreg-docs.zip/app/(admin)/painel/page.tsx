import { requirePermission } from "@/modules/shared/auth/permissions";

export default async function PainelPage() {
  await requirePermission("orders:read");

  return (
    <main className="mx-auto min-h-screen max-w-6xl px-6 py-10">
      <h1 className="text-3xl font-semibold text-slate-950">Painel operacional</h1>
      <p className="mt-3 text-slate-700">
        Acesso protegido por sessão, empresa e permissões do usuário.
      </p>
    </main>
  );
}
