import { listAdminProducts } from "@/modules/catalog/queries";
import { formatCatalogPrice, formatQuantity } from "@/modules/catalog/product-domain";
import { requirePermission } from "@/modules/shared/auth/permissions";

const measurementLabels = {
  WEIGHT: "Peso",
  UNIT: "Unidade",
  PACKAGE: "Pacote",
  VOLUME: "Volume",
  BOX: "Caixa"
};

export default async function ProdutosPage() {
  const context = await requirePermission("inventory:read");
  const products = await listAdminProducts(context.businessId);

  return (
    <main className="mx-auto min-h-screen max-w-6xl px-6 py-8">
      <div className="flex flex-col gap-2 border-b border-slate-200 pb-6">
        <p className="text-sm font-semibold uppercase text-emerald-700">Catálogo</p>
        <h1 className="text-3xl font-semibold text-slate-950">Produtos</h1>
        <p className="max-w-3xl text-slate-700">
          Cadastre produtos por peso, unidade, pacote, volume ou caixa. Os preços
          ativos são preservados nos pedidos para manter o histórico comercial.
        </p>
      </div>

      <section className="mt-6 overflow-hidden border border-slate-200 bg-white">
        <div className="grid grid-cols-[1.5fr_1fr_1fr_1fr] gap-4 bg-slate-100 px-4 py-3 text-sm font-semibold text-slate-700">
          <span>Produto</span>
          <span>Venda</span>
          <span>Preço atual</span>
          <span>Unidades</span>
        </div>
        {products.length === 0 ? (
          <div className="px-4 py-10 text-slate-600">
            Nenhum produto cadastrado ainda.
          </div>
        ) : (
          products.map((product) => {
            const price = product.prices[0];
            return (
              <article
                className="grid grid-cols-[1.5fr_1fr_1fr_1fr] gap-4 border-t border-slate-200 px-4 py-4 text-sm"
                key={product.id}
              >
                <div>
                  <h2 className="font-semibold text-slate-950">{product.name}</h2>
                  <p className="text-slate-600">{product.category?.name ?? "Sem categoria"}</p>
                  {!product.isActive ? (
                    <p className="mt-1 font-medium text-red-700">Inativo</p>
                  ) : null}
                </div>
                <div className="text-slate-700">
                  <p>{measurementLabels[product.measurementType]}</p>
                  <p>
                    Mínimo:{" "}
                    {formatQuantity({
                      measurementType: product.measurementType,
                      quantity: product.minimumOrderQuantity
                    })}
                  </p>
                  <p>
                    Incremento:{" "}
                    {formatQuantity({
                      measurementType: product.measurementType,
                      quantity: product.sellingIncrement
                    })}
                  </p>
                </div>
                <div className="font-semibold text-slate-950">
                  {price
                    ? formatCatalogPrice({
                        priceCents: price.priceCents,
                        basisQuantity: price.basisQuantity,
                        basisUnit: price.basisUnit
                      })
                    : "Sem preço ativo"}
                </div>
                <div className="text-slate-700">
                  {product.availability.length === 0
                    ? "Sem disponibilidade"
                    : product.availability
                        .map(
                          (availability) =>
                            `${availability.branch.name}: ${
                              availability.isAvailable ? "disponível" : "indisponível"
                            }`
                        )
                        .join(", ")}
                </div>
              </article>
            );
          })
        )}
      </section>
    </main>
  );
}
