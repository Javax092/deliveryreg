import { getManagementDashboard } from "@/modules/management/dashboard";
import { formatBRL } from "@/modules/shared/money/money";
import { formatBusinessDateTime } from "@/modules/shared/time/timezone";
import { requirePermission } from "@/modules/shared/auth/permissions";

export const dynamic = "force-dynamic";

const funnelLabels: Record<string, string> = {
  catalog_viewed: "Acessos ao catálogo",
  product_viewed: "Produtos vistos",
  product_added: "Adições ao carrinho",
  cart_viewed: "Carrinhos vistos",
  checkout_started: "Checkouts iniciados",
  lead_created: "Leads criados",
  order_created: "Pedidos criados",
  order_completed: "Compras finalizadas"
};

export default async function GestaoPage() {
  const context = await requirePermission("audit:read");
  const to = new Date();
  const from = new Date(to.getTime() - 30 * 24 * 60 * 60 * 1000);
  const dashboard = await getManagementDashboard({
    businessId: context.businessId,
    from,
    to
  });

  return (
    <main className="min-h-screen bg-slate-100 px-4 py-6">
      <div className="mx-auto max-w-6xl">
        <h1 className="text-3xl font-semibold text-slate-950">Gestão</h1>
        <p className="mt-2 text-slate-700">
          Período: {formatBusinessDateTime(dashboard.period.from)} até{" "}
          {formatBusinessDateTime(dashboard.period.to)}
        </p>

        <section className="mt-6 grid gap-3 md:grid-cols-3">
          <Metric label="Faturamento" value={formatBRL(dashboard.sales.revenueCents)} />
          <Metric label="Pedidos/vendas" value={String(dashboard.sales.orders)} />
          <Metric
            label="Ticket médio"
            value={
              dashboard.sales.averageTicketCents === null
                ? "dados insuficientes"
                : formatBRL(dashboard.sales.averageTicketCents)
            }
          />
          <Metric label="Kg vendidos" value={`${(dashboard.sales.soldWeightGrams / 1000).toFixed(3)} kg`} />
          <Metric label="Vendas presenciais" value={formatBRL(dashboard.sales.posRevenueCents)} />
          <Metric label="Vendas digitais" value={formatBRL(dashboard.sales.digitalRevenueCents)} />
        </section>

        <section className="mt-6 grid gap-4 lg:grid-cols-3">
          <Panel title="Produtos">
            {dashboard.products.length === 0 ? (
              <p>dados insuficientes</p>
            ) : (
              dashboard.products.map((product) => (
                <Line
                  key={product.name}
                  label={product.name}
                  value={`${product.quantity} / ${formatBRL(product.revenueCents)}`}
                />
              ))
            )}
          </Panel>
          <Panel title="Unidades">
            {dashboard.branches.map((branch) => (
              <Line
                key={branch.branchId}
                label={branch.name}
                value={`${branch.orders} vendas / ${formatBRL(branch.revenueCents)}`}
              />
            ))}
          </Panel>
          <Panel title="Funil">
            {Object.entries(funnelLabels).map(([event, label]) => (
              <Line key={event} label={label} value={String(dashboard.funnel[event] ?? 0)} />
            ))}
          </Panel>
        </section>
      </div>
    </main>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-white p-4">
      <p className="text-sm text-slate-600">{label}</p>
      <p className="mt-1 text-2xl font-semibold text-slate-950">{value}</p>
    </div>
  );
}

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-lg bg-white p-4">
      <h2 className="font-semibold text-slate-950">{title}</h2>
      <div className="mt-3 space-y-2 text-sm text-slate-700">{children}</div>
    </section>
  );
}

function Line({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-3 border-t border-slate-100 pt-2">
      <span>{label}</span>
      <span className="font-semibold text-slate-950">{value}</span>
    </div>
  );
}
