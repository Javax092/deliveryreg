"use server";

import { revalidatePath } from "next/cache";

import { assignDelivery, transitionAssignedDelivery } from "@/modules/delivery/operation";
import { getCurrentUserContext } from "@/modules/shared/auth/permissions";

export async function assignDeliveryAction(formData: FormData) {
  const context = await getCurrentUserContext();
  await assignDelivery({
    context,
    deliveryId: String(formData.get("deliveryId")),
    deliveryUserId: String(formData.get("deliveryUserId"))
  });
  revalidatePath("/entregas");
}

export async function markPickedUp(formData: FormData) {
  const context = await getCurrentUserContext();
  await transitionAssignedDelivery({
    context,
    deliveryId: String(formData.get("deliveryId")),
    toStatus: "PICKED_UP"
  });
  revalidatePath("/entregas");
}

export async function markOnRoute(formData: FormData) {
  const context = await getCurrentUserContext();
  await transitionAssignedDelivery({
    context,
    deliveryId: String(formData.get("deliveryId")),
    toStatus: "ON_ROUTE"
  });
  revalidatePath("/entregas");
}

export async function markDelivered(formData: FormData) {
  const context = await getCurrentUserContext();
  await transitionAssignedDelivery({
    context,
    deliveryId: String(formData.get("deliveryId")),
    toStatus: "DELIVERED"
  });
  revalidatePath("/entregas");
}

export async function markFailed(formData: FormData) {
  const context = await getCurrentUserContext();
  await transitionAssignedDelivery({
    context,
    deliveryId: String(formData.get("deliveryId")),
    toStatus: "FAILED",
    failureReason: "Falha registrada pelo entregador"
  });
  revalidatePath("/entregas");
}
